package com.example.mywork

class New(val name:String, val imageId: Int,val url: String) {
}