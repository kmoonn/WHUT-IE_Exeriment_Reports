package com.example.mywork

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main_note.*

class MainActivity : AppCompatActivity() {

    private var noteList = ArrayList<Note>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_note)
        initNotes()
        val adapter = NoteAdapter(this, R.layout.note_item, noteList)
        listView.adapter = adapter
        listView.setOnItemClickListener { parent, view, position, id ->
        }
        listView.setOnItemClickListener { _, _, position, _ ->
            val new = noteList[position]
            Toast.makeText(this, "正在加载", Toast.LENGTH_SHORT).show()
            val id = new.id
            val intent = Intent(this,ReadActivity::class.java)
            intent.putExtra("id",id)
            startActivity(intent)
        }
    }

    private var dbHelper = MyDatabaseHelper(this,"Note.db",1)

    private fun initNotes() {
        val db = dbHelper.writableDatabase
        val cursor = db.query("Note",null,null,null,null,null,"id DESC")
        if(cursor.moveToFirst()){
            do {
                val id = cursor.getInt(cursor.getColumnIndex("id"))
                val title = cursor.getString(cursor.getColumnIndex("title"))
                noteList.add(Note(id, title, R.drawable.flag))
            }while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_exit -> {
                Toast.makeText(this,"Exit Succeed",Toast.LENGTH_SHORT).show()
                finish()
                true
            }
            R.id.action_write -> {
                val intent = Intent(this,WriteActivity::class.java)
                startActivity(intent)
                true
            }
            R.id.action_news -> {
                val intent = Intent(this,NewMainActivity::class.java)
                startActivity(intent)
                true
            }
            R.id.action_web -> {
                val intent = Intent(this,WebviewActivity::class.java)
                startActivity(intent)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main,menu)
        return true
    }
}