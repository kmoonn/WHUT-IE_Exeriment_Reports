package com.example.mywork

import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView

class NoteAdapter(activity: Activity, val resourceId: Int, data: List<Note>) : ArrayAdapter<Note>(activity, resourceId, data) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view: View
        val viewHolder: ViewHolder
        if (convertView == null) {
            view = LayoutInflater.from(context).inflate(resourceId, parent, false)
            val noteImage: ImageView = view.findViewById(R.id.noteImage)
            val noteName: TextView = view.findViewById(R.id.noteName)
            viewHolder = ViewHolder(noteImage, noteName)
            view.tag = viewHolder
        } else {
            view = convertView
            viewHolder = view.tag as ViewHolder
        }

        val note = getItem(position)
        if (note != null) {
            viewHolder.noteImage.setImageResource(note.imageId)
            viewHolder.noteName.text = note.title
        }
        return view
    }

    inner class ViewHolder(val noteImage: ImageView, val noteName: TextView)

}