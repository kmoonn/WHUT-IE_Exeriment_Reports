package com.example.mywork

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main_note.*

class NewMainActivity : AppCompatActivity() {

    private val newList = ArrayList<New>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_new)
        initNews()
        val adapter = NewAdapter(this, R.layout.new_item, newList)
        listView.adapter = adapter
        listView.setOnItemClickListener { parent, view, position, id ->
        }
        listView.setOnItemClickListener { _, _, position, _ ->
            val new = newList[position]
            Toast.makeText(this, "正在加载", Toast.LENGTH_SHORT).show()
            val url = new.url
            val intent = Intent(this,WebviewActivity::class.java)
            intent.putExtra("url",url)
            startActivity(intent)
        }
    }


    private fun initNews() {
        repeat(2) {
            newList.add(New("“空中打字”“虹膜识别”“磁吸充电”……苹果混合现实头显多少钱？", R.drawable.item_1,"https://www.163.com/dy/article/I38PANH10530I1ON.html"))
            newList.add(New("ChatGPT企业版订阅服务将推出丨AIGC大事日报", R.drawable.item_2,"https://www.163.com/dy/article/I38FTTIO051180F7.html"))
            newList.add(New("消息称Meta计划开发新AI芯片 此前因迟迟未用GPU", R.drawable.item_3,"https://www.163.com/dy/article/I382UH2E05198CJN.html"))
            newList.add(New("pico有机会成为下一个switch或者ps吗？", R.drawable.item_4,"https://www.163.com/dy/article/I381842M05118O92.html"))
            newList.add(New("泛娱乐社交场景繁荣遇上AIGC新机会，带给创业者", R.drawable.item_5,"https://www.163.com/dy/article/I364GU4R0511844G.html"))
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_exit -> {
                Toast.makeText(this,"Exit Succeed",Toast.LENGTH_SHORT).show()
                finish()
                true
            }
            R.id.action_write -> {
                val intent = Intent(this,WriteActivity::class.java)
                startActivity(intent)
                true
            }
            R.id.action_news -> {
                val intent = Intent(this,NewMainActivity::class.java)
                startActivity(intent)
                true
            }
            R.id.action_web -> {
                val intent = Intent(this,WebviewActivity::class.java)
                startActivity(intent)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main,menu)
        return true
    }

}