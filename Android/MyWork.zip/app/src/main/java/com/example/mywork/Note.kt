package com.example.mywork

class Note(val id: Int, val title: String, val imageId: Int)