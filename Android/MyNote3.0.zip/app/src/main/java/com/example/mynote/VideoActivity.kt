package com.example.mynote

import android.annotation.SuppressLint
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_video.*

class VideoActivity : AppCompatActivity() {
    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_video)
        val uri = Uri.parse("android.resource://$packageName/${R.raw.video}")
        videoView.setVideoURI(uri)
        videoText.setText("为期三天的中国发展高层论坛2023年年会今天（3月25日）在北京举行。来自国际组织、世界500强企业、全球工商界的100多位嘉宾，围绕经济复苏等话题进行交流和研讨。与会嘉宾纷纷表示，看好中国经济发展前景，并对中国高质量发展充满期待。")
        play.setOnClickListener {
            if (!videoView.isPlaying) {
                videoView.start() // 开始
            }
        }
        pause.setOnClickListener {
            if (videoView.isPlaying) {
                videoView.pause() // 暂停
            }
        }
        replay.setOnClickListener {
            if (videoView.isPlaying) {
                videoView.resume() // 重播
            }
        }
    }
    override fun onDestroy() {
        super.onDestroy()
        videoView.suspend()
    }
}
