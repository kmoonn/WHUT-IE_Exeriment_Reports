package com.example.mynote

class New(val id: Int, val title: String, val imageId: Int)