package com.example.mynote

class New(val name:String, val imageId: Int, val content:String)